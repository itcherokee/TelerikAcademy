﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    class HealthCatalyst : Supplement
    {
        private const int InitialHealthEffect = 3;

        public HealthCatalyst()
            : base(healthEffect: HealthCatalyst.InitialHealthEffect)
        {
        }
    }
}
