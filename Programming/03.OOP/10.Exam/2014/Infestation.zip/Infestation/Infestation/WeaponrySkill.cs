﻿namespace Infestation
{
    class WeaponrySkill : Supplement
    {
        public WeaponrySkill()
            : base()
        {
        }
    }
}