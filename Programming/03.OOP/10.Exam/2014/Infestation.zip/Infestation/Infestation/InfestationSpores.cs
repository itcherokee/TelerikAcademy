﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    class InfestationSpores:Supplement
    {
        private const int InitialPowerEffect = -1;
        private const int InitialAggressionEffect = 20;

        public InfestationSpores():base(InfestationSpores.InitialPowerEffect, InfestationSpores.InitialAggressionEffect)
        {
            
        }

        // Supplement does not have any effect.
        // o	The InfestationSpores Supplement does not accumulate like the other Supplements – 
        //          even if two or more Infestations are added, the total AggressionEffect stays 20 
        //          (Edit: the same goes for PowerEffect)

    }
}
